#ifndef ADMIN_CREDENTIALS
#define ADMIN_CREDENTIALS

#define ADMIN_LOGIN_ID "Prateek"
#define ADMIN_PASSWORD "qwerty12345"

#endif
